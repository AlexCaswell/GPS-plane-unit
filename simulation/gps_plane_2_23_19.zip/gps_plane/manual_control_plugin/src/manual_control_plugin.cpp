#include <gazebo/gazebo.hh>
#include <gazebo/gui/GuiEvents.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>
#include <gazebo/common/common.hh>
#include <gazebo/sensors/sensors.hh>
#include <ignition/math/Vector3.hh>
#include <ignition/math/Quaternion.hh>
#include <boost/bind.hpp>
#include <SerialStream.h>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <unistd.h>


namespace gazebo {
	class manualControlPlugin : public ModelPlugin {
		public: void Load(physics::ModelPtr _model, sdf::ElementPtr _sdf) {
			this->model = _model;

			//calls ConnectWorldUpdateBegin with OnUpdate function bound to this as callback (i think). The returned ConnectionPtr is stored in updateConnection
			this->serial_stream.Open(this->serial_port);
			this->serial_stream.SetBaudRate(LibSerial::SerialStreamBuf::BAUD_9600);
			this->serial_stream.SetCharSize(LibSerial::SerialStreamBuf::CHAR_SIZE_8);
			this->serial_stream.SetFlowControl(LibSerial::SerialStreamBuf::FLOW_CONTROL_NONE);
			this->serial_stream.SetParity(LibSerial::SerialStreamBuf::PARITY_NONE);
			this->serial_stream.SetNumOfStopBits(1);

			//Subscribe to sensor topics
			transport::NodePtr gps_node(new transport::Node());
			gps_node->Init("default");
			std::string topic_name = "~/gps_plane/plane_fuselage/gps/gps";
			this->gps_sub = gps_node->Subscribe(topic_name, &manualControlPlugin::updateGps, this);

			transport::NodePtr imu_node(new transport::Node());
			imu_node->Init("default");
			topic_name = "~/gps_plane/plane_fuselage/imu/imu";
			this->imu_sub = imu_node->Subscribe(topic_name, &manualControlPlugin::updateImu, this);

			this->updateConnection = event::Events::ConnectWorldUpdateBegin(std::bind(&manualControlPlugin::OnUpdate, this));

		}

		public: void OnUpdate() {

			if(this->serial_stream.IsOpen() && this->iterations%3 == 0) {
				char dataByte;
				this->serial_stream.get(dataByte);

				if(dataByte == '\n') { 
					this->applyControls();
					std::cout << "heading: " << this->heading << " altitude: " << this->altitude << " pitch: " << this->pitch << " roll: " << this->roll << "\n";
					this->line_index = 0;
				}else {
					this->current_line[this->line_index++] = dataByte;
				}
				
				
				this->iterations = 0;
			}

			this->iterations++;

		}

		public: void updateGps(ConstGPSPtr &_gps) { 
			this->altitude = _gps->altitude()*3.28084;
			this->longitude = _gps->longitude_deg();
			this->latitude = _gps->latitude_deg();
		}

		public: void updateImu(ConstIMUPtr &_imu) {
			ignition::math::Quaternion<double> quat(_imu->orientation().w(), _imu->orientation().x(), _imu->orientation().y(), _imu->orientation().z());
			this->heading = quat.Yaw()*57.296;
			this->pitch = quat.Pitch()*57.296;
			this->roll = quat.Roll()*57.296;
		}


		private: void setJointPosition(std::string name, int index, double position) {
			this->model->GetJoint(name)->SetUpperLimit(index, position);
			this->model->GetJoint(name)->SetLowerLimit(index, position);
		}

		private: double mapPwmToJoint(std::string joint_name, int pwm, int max, int min) {
			double pwm_max = 0;
			double pwm_min = 0;
			if(joint_name == "aileron") { pwm_max = 1940; pwm_min = 1080; }
			if(joint_name == "elevator") { pwm_max = 1920; pwm_min = 1110; }
			if(joint_name == "throttle") { pwm_max = 1770; pwm_min = 1100; }
			if(joint_name == "rudder") { pwm_max = 1880; pwm_min = 970; }

			double pwm_range = pwm_max-pwm_min;
			double range = max-min;
			double pwm_to_range = range/pwm_range;

			pwm = ((pwm < pwm_min) ? pwm_min : pwm);
			return (pwm-pwm_min)*pwm_to_range;
		}

		private: void applyControls() {
			if(this->current_line[19] == ' ') {
				int values[4];
				int values_ind = 0;

				char buff[4];
				int buff_ind = 0;

				for(int j = 0; j < 20; j++) {
					if(this->current_line[j] == ' ') {
						values[values_ind++] = atoi(buff);
						buff_ind = 0;
					}else {
						buff[buff_ind++] = this->current_line[j];
					}
				}

				// std::cout << "Aileron: " << values[0] << "   Elevator: " << values[1] << "   Throttle: " << values[2] << "   Rudder: " << values[3] << "\n";

				//apply throttle
				double force_mag = this->mapPwmToJoint("throttle", values[2], 1500, 0);
				ignition::math::Vector3d force = ignition::math::Vector3d(0, 0, force_mag);
				this->model->GetLink("prop_hub")->AddLinkForce(force);
				double throttle_gain = 0.6;
				force = ignition::math::Vector3d(0, 0, (-force_mag)+force_mag*throttle_gain);
				this->model->GetLink("prop_hub")->AddLinkForce(force);

				//apply control surfaces
				double aileron = this->mapPwmToJoint("aileron", values[0], 90, 0);
				aileron = ((aileron <= 45) ? 45-aileron : -(aileron-45));
				double elevator = this->mapPwmToJoint("elevator", values[1], 90, 0);
				elevator = ((elevator <= 45) ? 45-elevator : -(elevator-45));
				double rudder = this->mapPwmToJoint("elevator", values[3], 90, 0);
				rudder = ((rudder <= 45) ? 45-rudder : -(rudder-45));
				this->setJointPosition("revolute_aileron_left", 0, aileron*0.01745);
				this->setJointPosition("revolute_aileron_right", 0, -aileron*0.01745);
				this->setJointPosition("revolute_elevator", 0, -elevator*0.01745);
				this->setJointPosition("revolute_rudder", 0, -rudder*0.01745);

			}
		}

		private: int iterations = 0;
		private: char current_line[20];
		private: int line_index = 0;

		private: double heading = 0;
		private: double altitude = 0;
		private: double longitude = 0;
		private: double latitude = 0;
		private: double pitch = 0;
		private: double roll = 0;

		private: LibSerial::SerialStream serial_stream;
		private: std::string serial_port = "/dev/ttyUSB0";

		private: physics::ModelPtr model;
		private: event::ConnectionPtr updateConnection;

		private: transport::SubscriberPtr gps_sub;
		private: transport::SubscriberPtr imu_sub;
	};
	GZ_REGISTER_MODEL_PLUGIN(manualControlPlugin);
}
