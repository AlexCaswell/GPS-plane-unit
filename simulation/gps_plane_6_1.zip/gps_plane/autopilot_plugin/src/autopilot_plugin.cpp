#include <gazebo/gazebo.hh>
#include <gazebo/gui/GuiEvents.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>
#include <gazebo/common/common.hh>
#include <gazebo/sensors/sensors.hh>
#include <ignition/math/Vector3.hh>
#include <ignition/math/Quaternion.hh>
#include <boost/bind.hpp>
#include <cstdlib>
#include <vector>
#include <GeographicLib/Geocentric.hpp>
#include <GeographicLib/LocalCartesian.hpp>
#include <cstring>
#include <iostream>
#include <unistd.h>


class PID {

	public: PID() {}

	public: PID(double kp, double ki, double kd) {
		this->kp = kp;
		this->ki = ki;
		this->kd = kd;
	}

	public: void updateGain(double error) {
		this->error = error;

		this->i_term += this->error;
		this->i_term *= this->ki;

		double rise = this->error - this->previous_error;
		this->previous_error = this->error;
		double run = 1;
		double d_term = (rise/run)*this->kd;

		this->total_gain = error*kp + i_term + d_term;
	}

	public: double getTotalGain() {
		return this->total_gain;
	}

	private: double kp;
	private: double ki;
	private: double kd;
	private: double i_term;
	private: double total_gain = 0;
	private: double error = 0;
	private: double previous_error = 0;
};




namespace gazebo {
	class autopilotPlugin : public ModelPlugin {
		public: void Load(physics::ModelPtr _model, sdf::ElementPtr _sdf) {
			this->model = _model;

			//set tuning variables from sdf plugin element
			this->height_controller = this->stringToPID(_sdf->Get<std::string>("elevator_pid"));
			this->throttle_controller = this->stringToPID(_sdf->Get<std::string>("throttle_pid"));
			this->roll_controller = this->stringToPID(_sdf->Get<std::string>("roll_pid"));
			this->heading_controller = this->stringToPID(_sdf->Get<std::string>("heading_pid"));

			this->elevator_limit_1 = _sdf->Get<double>("elevator_limit_1");
			this->elevator_limit_2 = _sdf->Get<double>("elevator_limit_2");
			this->elevator_limit_final = _sdf->Get<double>("elevator_limit_final");
			this->elevator_cutoff = _sdf->Get<double>("elevator_limit_cutoff");

			this->throttle_limit = _sdf->Get<double>("throttle_limit");

			this->aileron_limit = _sdf->Get<double>("aileron_limit");
			this->elevator_turn_gain = _sdf->Get<double>("elevator_turn_gain");


			//Subscribe to sensor topics
			transport::NodePtr gps_node(new transport::Node());
			gps_node->Init("default");
			std::string topic_name = "~/gps_plane/plane_fuselage/gps/gps";
			this->gps_sub = gps_node->Subscribe(topic_name, &autopilotPlugin::updateGps, this);

			transport::NodePtr imu_node(new transport::Node());
			imu_node->Init("default");
			topic_name = "~/gps_plane/plane_fuselage/imu/imu";
			this->imu_sub = imu_node->Subscribe(topic_name, &autopilotPlugin::updateImu, this);

			//Load waypoints from file and initialize Geographic object
			std::stringstream in("1\n0\n\n0\n100\n41.88206119141624\n-88.1117585780525\n\n0\n100\n41.87741209971844\n-88.11345373414991\n\n0\n100\n41.87601411081567\n-88.10691987298964\n\n0\n100\n41.877987263416514\n-88.10180221818922\n\n0\n100\n41.882548447767\n-88.10417329095839\n\n0\n100\n41.877560117200424\n-88.1048752781636\n\n0\n100\n41.88353516265484\n-88.108008098293\n\n0\n50\n41.87835895242182\n-88.11004657714432\n");
			std::string line;
			std::string::size_type sz;
			std::string prev_line;
			
			bool lat = true;
			for(int i = 1; std::getline(in, line); i++) {
				if(i > 3) {
					if((i-2)%4 == 3 || (i-2)%4 == 0) {
						if(!lat) {
							this->waypoints[(this->waypoints.size()-1)][0] = std::stod(prev_line, &sz);
							this->waypoints[(this->waypoints.size()-1)][1] = std::stod(line, &sz);
							lat = true;
						}else {
							lat = false;
						}
						prev_line = line;
					}
					if((i-2)%4 == 2) {
						std::vector<double> item({0.0, 0.0, 0.0});
						this->waypoints.push_back(item);
						this->waypoints[(this->waypoints.size()-1)][2] = std::stod(line, &sz);
					}
				}
				if(line == "") i--;
			}

			this->proj = GeographicLib::LocalCartesian(this->lat0, this->lon0, 0, this->earth);
			//convert the waypoints from lat, lon, and height to x, y, and z relative to the world center coordinates
			for(int i = 0; i < this->waypoints.size(); i++) {
				double x, y, z;
				proj.Forward(this->waypoints[i][0], this->waypoints[i][1], this->waypoints[i][2]*0.3048, x, y, z);
				this->waypoints[i][0] = x;
				this->waypoints[i][1] = y;
				this->waypoints[i][2] = z;
			}



			this->updateConnection = event::Events::ConnectWorldUpdateBegin(std::bind(&autopilotPlugin::OnUpdate, this));

		}

		public: void OnUpdate() {

			if(this->iterations%30 == 0) {
				this->applyControls();
				this->iterations = 0;
			}

			this->iterations++;

		}

		public: void updateGps(ConstGPSPtr &_gps) {
			this->altitude = _gps->altitude();
			this->longitude = _gps->longitude_deg();
			this->latitude = _gps->latitude_deg();
		}

		public: void updateImu(ConstIMUPtr &_imu) {
			ignition::math::Quaternion<double> quat(_imu->orientation().w(), _imu->orientation().x(), _imu->orientation().y(), _imu->orientation().z());
			this->heading = quat.Yaw()*57.296;
			this->pitch = quat.Roll()*57.296;
			this->roll = quat.Pitch()*57.296;
		}

		private: PID stringToPID(std::string param) {
			double values[3];
			int v_index = 0;
			std::string::size_type sz;
			for(int i = 0; i < 3; i++) {
				if(i != 2) {
					values[v_index++] = std::stod(param.substr(0, param.find(" ")), &sz);
					param.erase(0, param.find(" ")+1);
				}else {
					values[v_index++] = std::stod(param, &sz);
				}
			}
			PID newpid(values[0], values[1], values[2]);
			return newpid;
		}

		private: void setJointPosition(std::string name, int index, double position) {
			this->model->GetJoint(name)->SetUpperLimit(index, position);
			this->model->GetJoint(name)->SetLowerLimit(index, position);
		}

		private: double lowHighFiler(double center, double value, double max_deviation) {
			int sign = ((value < 0) ? -1 : 1);
			if(std::abs(value) > max_deviation) {
				return (max_deviation*sign)+center; 
			}else {
				return value+center;
			}
		}

		private: double mapPwmToJoint(std::string joint_name, int pwm, int max, int min) {
			double pwm_max = 0;
			double pwm_min = 0;
			if(joint_name == "aileron") { pwm_max = 1940; pwm_min = 1080; }
			if(joint_name == "elevator") { pwm_max = 1920; pwm_min = 1110; }
			if(joint_name == "throttle") { pwm_max = 1770; pwm_min = 1120; }
			if(joint_name == "rudder") { pwm_max = 1880; pwm_min = 970; }

			double pwm_range = pwm_max-pwm_min;
			double range = max-min;
			double pwm_to_range = range/pwm_range;

			pwm = ((pwm < pwm_min) ? pwm_min : pwm);
			return (pwm-pwm_min)*pwm_to_range;
		}

		private: void applyControls() {

			double height_error = 0;

			//check if throttle is off, indicating autopilot on
			if(this->model->GetLink("prop_hub")->GetCollision(int(0))->GetName() == "autopilot_enabled") {
				if(!this->autopilot) std::cout << "autopilot_enabled" << "\n";
				this->autopilot = true;

				//Calculate errors and sum PID gains
				double target_height = this->waypoints[this->wp_index][2];
				double x2 = this->waypoints[this->wp_index][0];
				double y2 = this->waypoints[this->wp_index][1];
				
				double height_error = (target_height - this->altitude);
				double x1, y1, z1;
				this->proj.Forward(this->latitude, this->longitude, 0, x1, y1, z1);

				//invert x/y directions to form angle relative to vehicle
				x1 = -x1;
				y1 = -y1;

				double target_heading_deg = (std::atan2((y2-y1),(x2-x1))*57.296);

				//convert to 360 degrees
				target_heading_deg = ((target_heading_deg < 0) ? target_heading_deg + 360 : target_heading_deg);
				this->heading = ((this->heading < 0) ? this->heading + 360 : this->heading);

				double heading_error = 0;

				//calculate error and choose correct sign for opimal direction (neg = ccw)
				if(this->heading < target_heading_deg) {
					double cw = 360 - target_heading_deg + this->heading;
					double ccw = target_heading_deg - this->heading;
					if(cw <= ccw) {
						heading_error = cw;
					}else {
						heading_error = -ccw;
					}
				}else {
					double cw = this->heading - target_heading_deg;
					double ccw = 360 - this->heading + target_heading_deg;
					if(cw <= ccw) {
						heading_error = cw;
					}else {
						heading_error = -ccw;
					}
				}


				this->height_controller.updateGain(height_error);
				this->throttle_controller.updateGain(height_error);

				this->heading_controller.updateGain(heading_error);

				double roll_error = this->heading_controller.getTotalGain()-this->roll;
				this->roll_controller.updateGain(roll_error);

				std::cout << "heading: " << heading << ", " << target_heading_deg << ", " << heading_error << 
				 "  alt-error: " << height_error << " roll-error: " << roll_error << "\n";

				//Check for waypoint arrival
				if(std::abs(x1-x2) <= this->wp_radius_meters && std::abs(y1-y2) <= this->wp_radius_meters && abs(height_error) <= this->wp_radius_meters) {
					if(this->wp_index != this->waypoints.size()-1) {
						this->wp_index++;
					}else {
						this->wp_index = 0;
					}
				}


			}else {
				if(this->autopilot) {
					std::cout << "autopilot_disabled" << "\n";
					this->autopilot = false;
				}
			}


			//apply values from user or controllers
			double elevator, aileron, rudder, force_mag;
			if(this->autopilot) {

				rudder = 0;

				//heading
				double aileron_pwm_zero = 1510;
				double aileron = this->mapPwmToJoint("aileron", aileron_pwm_zero+this->roll_controller.getTotalGain(), 40, 0);
				aileron = 20-aileron;
				aileron = this->lowHighFiler(0, aileron, this->aileron_limit);

				//elevator
				double elevator_pwm_zero = 1510;
				elevator = this->mapPwmToJoint("elevator", elevator_pwm_zero+this->height_controller.getTotalGain(), 90, 0);
				elevator = 45-elevator;
				if(std::abs(height_error) > this->elevator_cutoff) {
					elevator = this->lowHighFiler(0, elevator, this->elevator_limit_1);
				}else {
					elevator = this->lowHighFiler(0, elevator, this->elevator_limit_2);
				}
				//add elevator compensation for turning
				elevator -= std::abs(this->roll*this->roll)*0.1*this->elevator_turn_gain;
				elevator = this->lowHighFiler(0, elevator, this->elevator_limit_final);

				//throttle
				double throttle_pwm_center = 1445;
				double throttle = throttle_pwm_center+this->throttle_controller.getTotalGain();
				force_mag = this->mapPwmToJoint("throttle", throttle, 1200, 0);
				force_mag = this->lowHighFiler(0, force_mag, this->throttle_limit);


				//apply values
				this->setJointPosition("revolute_aileron_left", 0, -aileron*0.01745);
				this->setJointPosition("revolute_aileron_right", 0, aileron*0.01745);
				this->setJointPosition("revolute_elevator", 0, elevator*0.01745);
				this->setJointPosition("revolute_rudder", 0, -rudder*0.01745);
				ignition::math::Vector3d force = ignition::math::Vector3d(0, 0, force_mag);
				this->model->GetLink("prop_hub")->AddLinkForce(force);
				double throttle_gain = 0.6;
				force = ignition::math::Vector3d(0, 0, (-force_mag)+force_mag*throttle_gain);
				this->model->GetLink("prop_hub")->AddLinkForce(force);
				
				
			}


		}

		private: int iterations = 0;

		private: bool autopilot = false;

		private: double heading = 0;
		private: double altitude = 0;
		private: double longitude = 0;
		private: double latitude = 0;
		private: double pitch = 0;
		private: double roll = 0;

		private: std::vector<std::vector<double> > waypoints;
		private: int wp_index = 0;
		private: GeographicLib::LocalCartesian proj;
		private: const GeographicLib::Geocentric& earth = GeographicLib::Geocentric::WGS84();
		private: double lat0 = 41.87986;
		private: double lon0 = -88.11111;
		private: double wp_radius_meters = 20;

		private: PID height_controller;
		private: PID throttle_controller;
		private: PID heading_controller;
		private: PID roll_controller;
		private: double elevator_turn_gain;
		private: double elevator_limit_1;
		private: double elevator_limit_2;
		private: double elevator_limit_final;
		private: double elevator_cutoff;
		private: double aileron_limit;
		private: double throttle_limit;

		private: physics::ModelPtr model;
		private: event::ConnectionPtr updateConnection;

		private: transport::SubscriberPtr gps_sub;
		private: transport::SubscriberPtr imu_sub;
	};
	GZ_REGISTER_MODEL_PLUGIN(autopilotPlugin);
}
