#include <gazebo/gazebo.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>
#include <ignition/math/Quaternion.hh>
#include <boost/bind.hpp>
#include <SerialStream.h>
#include <GeographicLib/Geocentric.hpp>
#include <GeographicLib/LocalCartesian.hpp>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <unistd.h>


namespace gazebo {
	class manualControlPlugin : public ModelPlugin {
		public: void Load(physics::ModelPtr _model, sdf::ElementPtr _sdf) {
			this->model = _model;


			if(this->model->GetLink("prop_hub")->GetCollision(int(0))->GetName() != "autopilot_enabled") {
				
				//calls ConnectWorldUpdateBegin with OnUpdate function bound to this as callback (i think). The returned ConnectionPtr is stored in updateConnection
				this->updateConnection = event::Events::ConnectWorldUpdateBegin(std::bind(&manualControlPlugin::OnUpdate, this));

				this->serial_stream.Open(this->serial_port);
				this->serial_stream.SetBaudRate(LibSerial::SerialStreamBuf::BAUD_9600);
				this->serial_stream.SetCharSize(LibSerial::SerialStreamBuf::CHAR_SIZE_8);
				this->serial_stream.SetFlowControl(LibSerial::SerialStreamBuf::FLOW_CONTROL_NONE);
				this->serial_stream.SetParity(LibSerial::SerialStreamBuf::PARITY_NONE);
				this->serial_stream.SetNumOfStopBits(1);

				//create gps/imu nodes and subscribe to appropriate topics
				transport::NodePtr gps_node(new transport::Node());
				gps_node->Init("default");
				std::string topic_name = "~/gps_plane/plane_fuselage/gps/gps";
				this->gps_sub = gps_node->Subscribe(topic_name, &manualControlPlugin::updateGps, this);

				transport::NodePtr imu_node(new transport::Node());
				imu_node->Init("default");
				topic_name = "~/gps_plane/plane_fuselage/imu/imu";
				this->imu_sub = imu_node->Subscribe(topic_name, &manualControlPlugin::updateImu, this);

				//assign geographiclib lc object
				this->proj = GeographicLib::LocalCartesian(this->lat0, this->lon0, 0, this->earth);

			}
			
		}

		public: void OnUpdate() {

			//Fixable inconvenience: autopilot can not be turned off
			if(!this->autopilot) {
				if(this->serial_stream.IsOpen() && this->iterations%3 == 0) {
					char dataByte;
					this->serial_stream.get(dataByte);

					if(dataByte == '\n') { 
						this->applyControls();
						this->line_index = 0;
					}else {
						this->current_line[this->line_index++] = dataByte;
					}
					
					
					this->iterations = 0;
				}

				this->iterations++;
			}

		}

		public: void updateGps(ConstGPSPtr &_gps) {
			this->altitude = _gps->altitude();
			this->longitude = _gps->longitude_deg();
			this->latitude = _gps->latitude_deg();
		}

		public: void updateImu(ConstIMUPtr &_imu) {
			ignition::math::Quaternion<double> quat(_imu->orientation().w(), _imu->orientation().x(), _imu->orientation().y(), _imu->orientation().z());
			this->heading = quat.Yaw()*57.296;
			this->pitch = quat.Roll()*57.296;
			this->roll = quat.Pitch()*57.296;
		}

		private: void setJointPosition(std::string name, int index, double position) {
			this->model->GetJoint(name)->SetUpperLimit(index, position);
			this->model->GetJoint(name)->SetLowerLimit(index, position);
		}


		private: double mapPwmToJoint(std::string joint_name, int pwm, int max, int min) {
			double pwm_max = 0;
			double pwm_min = 0;
			if(joint_name == "aileron") { pwm_max = 1940; pwm_min = 1080; }
			if(joint_name == "elevator") { pwm_max = 1920; pwm_min = 1110; }
			if(joint_name == "throttle") { pwm_max = 1770; pwm_min = 1120; }
			if(joint_name == "rudder") { pwm_max = 1880; pwm_min = 970; }

			double pwm_range = pwm_max-pwm_min;
			double range = max-min;
			double pwm_to_range = range/pwm_range;

			pwm = ((pwm < pwm_min) ? pwm_min : pwm);
			return (pwm-pwm_min)*pwm_to_range;
		}

		private: void applyControls() {
			if(this->current_line[19] == ' ') {
				//read in controller values and store in array
				int values[4];
				int values_ind = 0;
				char buff[4];
				int buff_ind = 0;
				for(int j = 0; j < 20; j++) {
					if(this->current_line[j] == ' ') {
						values[values_ind++] = atoi(buff);
						buff_ind = 0;
					}else {
						buff[buff_ind++] = this->current_line[j];
					}
				}
				// std::cout << "Aileron: " << values[0] << "   Elevator: " << values[1] << "   Throttle: " << values[2] << "   Rudder: " << values[3] << "\n";

				//check if throttle is off, indicating autopilot on
				if(mapPwmToJoint("throttle", values[2], 1, 0) <= 0) {
					this->autopilot = true;
					//edit prop hub collision name to indicate autopilot on
					this->model->GetLink("prop_hub")->GetCollision(int(0))->SetName("autopilot_enabled");
				}else {
					if(this->autopilot) {
						this->autopilot = false;
						this->model->GetLink("prop_hub")->GetCollision(int(0))->SetName("autopilot_disabled");
					}
				}



				//apply values from remote
				double elevator, aileron, rudder, force_mag;
				if(this->autopilot) {

				}else {
					//throttle
					force_mag = this->mapPwmToJoint("throttle", values[2], 1200, 0);

					//control surfaces
					aileron = this->mapPwmToJoint("aileron", values[0], 90, 0);
					aileron = 45-aileron;
					elevator = this->mapPwmToJoint("elevator", values[1], 90, 0);
					elevator = 45-elevator;
					rudder = this->mapPwmToJoint("rudder", values[3], 90, 0);
					rudder = 45-rudder;

					//apply values
					this->setJointPosition("revolute_aileron_left", 0, aileron*0.01745);
					this->setJointPosition("revolute_aileron_right", 0, -aileron*0.01745);
					this->setJointPosition("revolute_elevator", 0, -elevator*0.01745);
					this->setJointPosition("revolute_rudder", 0, -rudder*0.01745);
					ignition::math::Vector3d force = ignition::math::Vector3d(0, 0, force_mag);
					this->model->GetLink("prop_hub")->AddLinkForce(force);
					double throttle_gain = 0.6;
					force = ignition::math::Vector3d(0, 0, (-force_mag)+force_mag*throttle_gain);
					this->model->GetLink("prop_hub")->AddLinkForce(force);


					//calculate and display targets and errors
					double height_error = (this->target_height - this->altitude);
					double x1, y1, z1;
					this->proj.Forward(this->latitude, this->longitude, 0, x1, y1, z1);
					double x2 = 0;
					double y2 = 0;

					//invert x/y directions to form angle relative to vehice
					x1 = -x1;
					y1 = -y1;

					double target_heading_deg = (std::atan2((y2-y1),(x2-x1))*57.296);

					//convert to 360 degrees
					target_heading_deg = ((target_heading_deg < 0) ? target_heading_deg + 360 : target_heading_deg);
					this->heading = ((this->heading < 0) ? this->heading + 360 : this->heading);

					double heading_error = 0;

					//calculate error and choose correct sign for opimal direction (neg = ccw)
					if(this->heading < target_heading_deg) {
						double cw = 360 - target_heading_deg + this->heading;
						double ccw = target_heading_deg - this->heading;
						if(cw <= ccw) {
							heading_error = cw;
						}else {
							heading_error = -ccw;
						}
					}else {
						double cw = this->heading - target_heading_deg;
						double ccw = 360 - this->heading + target_heading_deg;
						if(cw <= ccw) {
							heading_error = cw;
						}else {
							heading_error = -ccw;
						}
					}


					std::cout << "heading: " << heading << ", " << target_heading_deg << ", " << heading_error << 
					 "  alt-error: " << height_error << "\n";

				}

			}
		}

		private: int iterations = 0;
		private: char current_line[20];
		private: int line_index = 0;

		private: bool autopilot = false;

		private: transport::SubscriberPtr gps_sub;
		private: transport::SubscriberPtr imu_sub;

		private: double altitude = 0, longitude = 0, latitude = 0;
		private: double heading = 0, pitch = 0, roll = 0;

		private: GeographicLib::LocalCartesian proj;
		private: const GeographicLib::Geocentric& earth = GeographicLib::Geocentric::WGS84();
		private: double lat0 = 41.87986;
		private: double lon0 = -88.11111;
		private: double target_height = 30;

		private: LibSerial::SerialStream serial_stream;
		private: std::string serial_port = "/dev/ttyUSB0";

		private: physics::ModelPtr model;
		private: event::ConnectionPtr updateConnection;
	};
	GZ_REGISTER_MODEL_PLUGIN(manualControlPlugin);
}
